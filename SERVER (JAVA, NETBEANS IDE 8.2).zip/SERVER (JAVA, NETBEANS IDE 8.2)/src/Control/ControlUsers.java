/* This Project is Under License of Prince Alvin Yusuf 046
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import Entity.EntityStock;
import Entity.EntityUsers;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 
 */
public class ControlUsers {
    public Connection con=null;
    public Statement stat=null;
    public ResultSet res=null;
    
    public ControlUsers(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/users","root","");
            stat=con.createStatement();
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    public void TambahUsers(EntityUsers users) {
        String sqlbeli = "INSERT INTO users_table VALUES('"
                +users.GetNoUsers()+"','"
                +users.GetIDUsers()+"','"
                +users.GetJml()+"','"
                +users.GetTanggal()+"','"
                +users.GetPhoto()+"','"
                +users.GetSaldo()+"')";
        try {
            stat.executeUpdate(sqlbeli);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan");
        }
    }
    
    public void UbahUsers(EntityUsers users) {
        try {
            stat.executeUpdate("UPDATE users_table SET name='"+users.GetIDUsers()+
                              "',email='"+users.GetJml()+
                              "',password='"+users.GetTanggal()+
                              "',photo='"+users.GetPhoto()+
                              "',saldo='"+users.GetSaldo()+
                              "' WHERE id='"+users.GetNoUsers()+"'");
            JOptionPane.showMessageDialog(null, "Data Telah Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Diubah");
        }
    }
    
    public void HapusUsers(EntityUsers users){
        try {
            stat.executeUpdate("DELETE FROM users_table WHERE id='"+users.GetNoUsers()+"';");
            JOptionPane.showMessageDialog(null, "Data Telah Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Dihapus");
        }
    }
    
    
}
