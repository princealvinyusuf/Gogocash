/* This Project is Under License of Prince Alvin Yusuf 046
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import Entity.EntityStock;
import Entity.EntityNotes;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 
 */
public class ControlNotes {
    public Connection con=null;
    public Statement stat=null;
    public ResultSet res=null;
    
    public ControlNotes(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/users","root","");
            stat=con.createStatement();
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    public void TambahNotes(EntityNotes notes) {
        String sqlbeli = "INSERT INTO notes VALUES('"
                +notes.GetNoNotes()+"','"
                +notes.GetIDNotes()+"','"
                +notes.GetJml()+"','"
                +notes.GetTanggal()+"','"
                +notes.GetPhoto()+"','"
                +notes.GetSaldo()+"')";
        try {
            stat.executeUpdate(sqlbeli);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan");
        }
    }
    
    public void UbahNotes(EntityNotes notes) {
        try {
            stat.executeUpdate("UPDATE notes SET name='"+notes.GetIDNotes()+
                              "',deskripsi='"+notes.GetJml()+
                              "',date='"+notes.GetTanggal()+
                              "',love='"+notes.GetPhoto()+
                              "',picture='"+notes.GetSaldo()+
                              "' WHERE id='"+notes.GetNoNotes()+"'");
            JOptionPane.showMessageDialog(null, "Data Telah Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Diubah");
        }
    }
    
    public void HapusNotes(EntityNotes notes){
        try {
            stat.executeUpdate("DELETE FROM notes WHERE id='"+notes.GetNoNotes()+"';");
            JOptionPane.showMessageDialog(null, "Data Telah Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Dihapus");
        }
    }
    
    
}
