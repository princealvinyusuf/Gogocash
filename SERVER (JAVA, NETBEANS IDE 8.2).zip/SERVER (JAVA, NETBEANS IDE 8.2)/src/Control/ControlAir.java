/* This Project is Under License of Prince Alvin Yusuf 046
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import Entity.EntityAir;
import Entity.EntityStock;
import Entity.EntityUsers;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 
 */
public class ControlAir {
    public Connection con=null;
    public Statement stat=null;
    public ResultSet res=null;
    
    public ControlAir(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/users","root","");
            stat=con.createStatement();
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
   
    public void TambahAir(EntityAir air) {
        String sqlair = "INSERT INTO air VALUES('"
                +air.GetIDair()+"','"
                +air.GetNAMAair()+"')";
        try {
            stat.executeUpdate(sqlair);
            JOptionPane.showMessageDialog(null, "Air Berhasil Disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Air Gagal Disimpan");
        }
    }
    
    public void UbahAir(EntityAir air) {
        try {
            stat.executeUpdate("UPDATE air SET idp='"+air.GetNAMAair()+
                              "' WHERE no='"+air.GetIDair()+"'");
            JOptionPane.showMessageDialog(null, "Air Telah Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Air Gagal Diubah");
        }
    }
    
    public void HapusAir(EntityAir air){
        try {
            stat.executeUpdate("DELETE FROM air WHERE no='"+air.GetIDair()+"';");
            JOptionPane.showMessageDialog(null, "Air Telah Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Air Gagal Dihapus");
        }
    }
}
