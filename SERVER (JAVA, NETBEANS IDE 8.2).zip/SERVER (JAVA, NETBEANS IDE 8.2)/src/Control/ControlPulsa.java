/* This Project is Under License of Prince Alvin Yusuf 046
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import Entity.EntityPulsa;
import Entity.EntityStock;
import Entity.EntityUsers;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 
 */
public class ControlPulsa {
    public Connection con=null;
    public Statement stat=null;
    public ResultSet res=null;
    
    public ControlPulsa(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/users","root","");
            stat=con.createStatement();
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
   
    public void TambahPulsa(EntityPulsa pulsa) {
        String sqlpulsa = "INSERT INTO pulsa VALUES('"
                +pulsa.GetIDpulsa()+"','"
                +pulsa.GetNAMApulsa()+"','"
                +pulsa.GetMERKpulsa()+"')";
        try {
            stat.executeUpdate(sqlpulsa);
            JOptionPane.showMessageDialog(null, "Pulsa Berhasil Disimpan");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Pulsa Gagal Disimpan");
        }
    }
    
    public void UbahPulsa(EntityPulsa pulsa) {
        try {
            stat.executeUpdate("UPDATE pulsa SET no_hp='"+pulsa.GetNAMApulsa()+
                              "',denom='"+pulsa.GetMERKpulsa()+
                              "' WHERE no='"+pulsa.GetIDpulsa()+"'");
            JOptionPane.showMessageDialog(null, "Pulsa Telah Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Pulsa Gagal Diubah");
        }
    }
    
    public void HapusPulsa(EntityPulsa pulsa){
        try {
            stat.executeUpdate("DELETE FROM pulsa WHERE no='"+pulsa.GetIDpulsa()+"';");
            JOptionPane.showMessageDialog(null, "Pulsa Telah Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Pulsa Gagal Dihapus");
        }
    }
}
