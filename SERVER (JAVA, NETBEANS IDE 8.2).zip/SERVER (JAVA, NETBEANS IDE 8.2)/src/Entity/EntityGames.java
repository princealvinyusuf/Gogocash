/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. This Project is Under License of Prince Alvin Yusuf 046
 */
package Entity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class EntityGames {
    String IDGames, NamaGames, MerkGames;
    
    public String GetIDgames(){
        return IDGames;
    }
    public String GetNAMAgames(){
        return NamaGames;
    }
    public String GetMERKgames(){
        return MerkGames;
    }
    
    public void setIDgames(String idgames){
        this.IDGames = idgames;
    }
    public void setNAMAgames(String nmgames){
        this.NamaGames = nmgames;
    }
    public void setMERKgames(String merkgames){
        this.MerkGames = merkgames;
    }
}
