/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. This Project is Under License of Prince Alvin Yusuf 046
 */
package Entity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class EntityPln {
    String IDPln, NamaPln;
    
    public String GetIDpln(){
        return IDPln;
    }
    public String GetNAMApln(){
        return NamaPln;
    }
    
    public void setIDpln(String idpln){
        this.IDPln = idpln;
    }
    public void setNAMApln(String nmpln){
        this.NamaPln = nmpln;
    }
}
