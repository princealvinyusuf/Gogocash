/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. This Project is Under License of Prince Alvin Yusuf 046
 */
package Entity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class EntityUsers {
    String NoUsers, Jml, IDUsers, Tanggal, Saldo, Photo;
    
    public String GetNoUsers(){
        return NoUsers;
    }
    public String GetIDUsers(){
        return IDUsers;
    }
    public String GetJml(){
        return Jml;
    }
    public String GetTanggal(){
        return Tanggal;
    }
    
    public String GetSaldo(){
        return Saldo;
    }
    
     public String GetPhoto(){
        return Photo;
    }
    
    public void setNoUsers(String nousers){
        this.NoUsers = nousers;
    }
    public void setIDUsers(String idusers){
        this.IDUsers = idusers;
    }
    public void setJml(String jumlah){
        this.Jml = jumlah;
    }
    public void setTanggal(String tanggal){
        this.Tanggal = tanggal;
    }
    public void setSaldo(String saldo){
        this.Saldo = saldo;
    }
    public void setPhoto(String photo){
        this.Photo = photo;
    }
}
