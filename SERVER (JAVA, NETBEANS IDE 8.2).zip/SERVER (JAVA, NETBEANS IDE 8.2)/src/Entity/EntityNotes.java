/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. This Project is Under License of Prince Alvin Yusuf 046
 */
package Entity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class EntityNotes {
    String NoNotes, Jml, IDNotes, Tanggal, Saldo, Photo;
    
    public String GetNoNotes(){
        return NoNotes;
    }
    public String GetIDNotes(){
        return IDNotes;
    }
    public String GetJml(){
        return Jml;
    }
    public String GetTanggal(){
        return Tanggal;
    }
    
    public String GetSaldo(){
        return Saldo;
    }
    
     public String GetPhoto(){
        return Photo;
    }
    
    public void setNoNotes(String nonotes){
        this.NoNotes = nonotes;
    }
    public void setIDNotes(String idnotes){
        this.IDNotes = idnotes;
    }
    public void setJml(String jumlah){
        this.Jml = jumlah;
    }
    public void setTanggal(String tanggal){
        this.Tanggal = tanggal;
    }
    public void setSaldo(String saldo){
        this.Saldo = saldo;
    }
    public void setPhoto(String photo){
        this.Photo = photo;
    }
}
