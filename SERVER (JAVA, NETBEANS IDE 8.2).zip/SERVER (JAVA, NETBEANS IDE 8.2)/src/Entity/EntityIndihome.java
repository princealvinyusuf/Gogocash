/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. This Project is Under License of Prince Alvin Yusuf 046
 */
package Entity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author 
 */
public class EntityIndihome {
    String IDIndihome, NamaIndihome;
    
    public String GetIDindihome(){
        return IDIndihome;
    }
    public String GetNAMAindihome(){
        return NamaIndihome;
    }
    
    public void setIDindihome(String idindihome){
        this.IDIndihome = idindihome;
    }
    public void setNAMAindihome(String nmindihome){
        this.NamaIndihome = nmindihome;
    }
}
